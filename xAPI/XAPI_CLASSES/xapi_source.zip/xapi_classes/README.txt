All of these classes must be placed in this directory:
Documents/Arduino/libraries